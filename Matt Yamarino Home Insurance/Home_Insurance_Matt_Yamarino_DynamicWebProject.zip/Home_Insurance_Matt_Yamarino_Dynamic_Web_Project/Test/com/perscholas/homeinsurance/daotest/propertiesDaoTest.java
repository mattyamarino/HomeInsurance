package com.perscholas.homeinsurance.daotest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.perscholas.homeinsurance.dao.propertiesDao;
import com.perscholas.homeinsurance.model.properties;



@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class propertiesDaoTest {

	propertiesDao propDao = new propertiesDao();
	properties prop = new properties(1,1,1,1,"test","test","test",1,1,false);
	 
		
		@Test
		public void addPropertiesTest() throws SQLException, ClassNotFoundException, IOException {		
			boolean t = propDao.insertProperties(prop);
			assertEquals (true, t);
			
			boolean boo = false;
			List<properties> pList = propDao.getAllProperties();
			for(properties p:pList) if (p.getLocationId() == 1) {boo = true;}
			assertTrue(boo);
	}

		@Test
		public void getAllPropertiesTest() throws SQLException {
			List<properties> pList = propDao.getAllProperties();
			boolean boo = false;
			
			assertNotNull(pList);
			
			if (!pList.isEmpty()) {boo = true;}
			assertTrue(boo);
		}

	
	
}
