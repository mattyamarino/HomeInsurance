package com.perscholas.homeinsurance.daotest;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.perscholas.homeinsurance.dao.quoteDao;
import com.perscholas.homeinsurance.model.quote;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class quoteDaoTest {

	quoteDao quoteDao = new quoteDao();
	quote quote = new quote(1,1,1,1,1,1,1,1);
	
		@Test
		public void addQuoteTest() throws SQLException, ClassNotFoundException, IOException {		
		int t = quoteDao.insertQuote(quote);
		assert (t > 0);
		
		boolean boo = false;
		List<quote> pList = quoteDao.getAllQuotes();
		for(quote p:pList) if (p.getQuoteId() == t) {boo = true;}
		assertTrue(boo);
	}
		

		@Test
		public void getAllQuotesTest() throws SQLException {
			List<quote> pList = quoteDao.getAllQuotes();
			boolean boo = false;
			
			assertNotNull(pList);
			
			if (!pList.isEmpty()) {boo = true;}
			assertTrue(boo);

		
}
}
