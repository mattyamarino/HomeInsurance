package com.perscholas.homeinsurance.daotest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses(
		{ 
		userDaoTest.class,
		locationDaoTest.class,
		quoteDaoTest.class,
		policyDaoTest.class,
		propertiesDaoTest.class,
		homeOwnerDaoTest.class		
}
)

public class DaoTestSuite {

}
