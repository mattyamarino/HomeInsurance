package com.perscholas.homeinsurance.daotest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.perscholas.homeinsurance.dao.homeOwnerDao;
import com.perscholas.homeinsurance.model.homeOwner;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class homeOwnerDaoTest  {
	homeOwnerDao homeDao = new homeOwnerDao();
	
	@Test
	public void addHomeOwnerTest() throws SQLException, ClassNotFoundException, IOException {	
	homeOwner home = new homeOwner();	
	home.setUserId(1);
	home.setFirstName("test");
	home.setLastName("test");
	home.setDateOfBirth(LocalDate.parse("1985-10-10"));
	home.setRetired(true);
	home.setSsn(1234);
	home.setEmail("test");
	boolean t = homeDao.insertHomeOwner(home);
	assertEquals(true,t);
	}
	
	@Test
	public void getAllHomeOwners() throws SQLException {
	boolean boo = false;
	List<homeOwner> pList = homeDao.getAllHomeOwners();
	for(homeOwner p:pList) if (p.getUserId() == 1) {boo = true;}
	assertTrue(boo);
	
}
	

	
}
