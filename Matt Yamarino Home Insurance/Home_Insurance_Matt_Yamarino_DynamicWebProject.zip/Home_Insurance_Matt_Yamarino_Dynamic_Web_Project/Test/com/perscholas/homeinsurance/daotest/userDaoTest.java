package com.perscholas.homeinsurance.daotest;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.perscholas.homeinsurance.dao.userDao;
import com.perscholas.homeinsurance.model.user1;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class userDaoTest {

	userDao userDao = new userDao();
	user1 user = new user1("test", "test", "test");
	
	
	@Test
	public void addUserTest() throws SQLException, ClassNotFoundException, IOException {		
	
	int t = userDao.insertUser(user);
	assert (t > 0);
	
	boolean boo = false;
	List<user1> pList = userDao.getAllUsers();
	for(user1 p:pList) if (p.getUserId() == t) {boo = true;}
	assertTrue(boo);
	}
		
	
	@Test
	public void getAllUsersTest() throws SQLException {
	List<user1> pList = userDao.getAllUsers();
	boolean boo = false;
	
	assertNotNull(pList);
	
	if (!pList.isEmpty()) {boo = true;}
	assertTrue(boo);
	
	
	}


	
	
} 