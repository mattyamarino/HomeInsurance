package com.perscholas.homeinsurance.daotest;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.perscholas.homeinsurance.dao.policyDao;
import com.perscholas.homeinsurance.model.policy;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class policyDaoTest {
		policyDao policyDao = new policyDao();
		policy policy = new policy();


		@Test
		public void addPolicyTest() throws SQLException, ClassNotFoundException, IOException {	
		policy.setQuoteId(1);
		policy.setUserId(1);
		policy.setEffectiveDate(LocalDate.parse("2001-05-05"));
		policy.setEndDate(LocalDate.parse("2010-10-10"));
		policy.setTerm(1);
		policy.setPolicyStatus("test");
			
		int t = policyDao.insertPolicy(policy);
		assert (t > 0);
		
		boolean boo = false;
		List<policy> pList = policyDao.getAllPolicies();
		for(policy p:pList) if (p.getPolicyId() == t) {boo = true;}
		assertTrue(boo);
		
	}
		
		@Test
		public void getAllPoliciesTest() throws SQLException {
			
			List<policy> pList = policyDao.getAllPolicies();
			boolean boo = false;
			
			assertNotNull(pList);
			
			if (!pList.isEmpty()) {boo = true;}
			assertTrue(boo);
		}
		
		
}
