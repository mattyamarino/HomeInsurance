package com.perscholas.homeinsurance.automation;

import java.io.IOException;
import java.sql.SQLException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.perscholas.homeinsurance.bo.policyBo;
import com.perscholas.homeinsurance.bo.userBo;
import com.perscholas.homeinsurance.model.user1;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;

public class stepDef2 {

	static WebDriver driver;
//	int x = 0;
	
@Before
	public void setup() {
			
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Student\\Downloads\\chromedriver_win32\\chromedriver.exe");
	driver = new ChromeDriver();
				}
		
@Given ("^I go to home insurance website again$")
		
	public void Step_One() {
	driver.get("http://localhost:8080/Home_Insurance_Matt_Yamarino_Dynamic_Web_Project/");
	driver.manage().window().maximize();}

@And ("^I login as admin$")
	public void Step_Three() throws InterruptedException {
	
	Thread.sleep(3000);
		
	WebElement adminlink = driver.findElement(By.linkText("Admin Login"));
	adminlink.click();	
		
	WebElement usermake = driver.findElement(By.name("username"));
	usermake.sendKeys("admin");
	
	WebElement passmake = driver.findElement(By.name("password"));
	passmake.sendKeys("admin");
	
	Thread.sleep(3000);
	
	WebElement submit = driver.findElement(By.name("sub"));
	submit.click();
	}

@And ("^I find user and cancel their policy$")
	public void Step_Four() throws InterruptedException, SQLException, ClassNotFoundException, IOException { 
	
	userBo bo = new userBo();
	user1 u = bo.getUserbyUname("Test1111");
	String uid = Integer.toString(u.getUserId());
	int x = u.getUserId();
	
	WebElement search = driver.findElement(By.name("uid"));
	search.sendKeys(uid);
	
	Thread.sleep(3000);
	
	WebElement submit = driver.findElement(By.name("sub"));
	submit.click();
	
	Thread.sleep(3500);

	WebElement cancel = driver.findElement(By.name("cancel"));
	cancel.click();
	
	Thread.sleep(3000);
	
	WebElement submityes = driver.findElement(By.name("yes"));
	submityes.click();
	
	Thread.sleep(5000);
	
	policyBo pbo = new policyBo();	
	pbo.deleteTestData(x);
}	
	
@After 
	public void end(){
	driver.quit();
}	
	
	
}
