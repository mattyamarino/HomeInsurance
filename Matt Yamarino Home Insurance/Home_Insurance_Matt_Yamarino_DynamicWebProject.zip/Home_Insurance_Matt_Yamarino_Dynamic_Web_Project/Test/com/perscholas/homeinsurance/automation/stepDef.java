package com.perscholas.homeinsurance.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;

public class stepDef {

static WebDriver driver;
	
@Before
	public void setup() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Student\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
			}
	
@Given ("^I go to home insurance website$")
	
	public void Step_One() {
		driver.get("http://localhost:8080/Home_Insurance_Matt_Yamarino_Dynamic_Web_Project/");
		driver.manage().window().maximize();}

@And ("^I register a new user$")
	public void Step_Two() throws InterruptedException {
	
	Thread.sleep(2000);
	
	WebElement reglink = driver.findElement(By.linkText("Register Here"));
	reglink.click();
	
	WebElement usermake = driver.findElement(By.name("username"));
	usermake.sendKeys("Test1111");
	
	WebElement passmake = driver.findElement(By.name("password"));
	passmake.sendKeys("password");
	
	WebElement confirm = driver.findElement(By.name("confirm"));
	confirm.sendKeys("password");
	
	Thread.sleep(3000);
	
	WebElement submit = driver.findElement(By.name("sub"));
	submit.click();
	
}

@And ("^I login$")
	public void Step_Three() throws InterruptedException {
	
	WebElement usermake = driver.findElement(By.name("username"));
	usermake.sendKeys("Test1111");
	
	WebElement passmake = driver.findElement(By.name("password"));
	passmake.sendKeys("password");
	
Thread.sleep(3000);
	
	WebElement submit = driver.findElement(By.name("sub"));
	submit.click();
	
	
}

@And ("^I get a new quote - location details$")
	public void Step_Four() throws InterruptedException {
	
	Thread.sleep(3000);
	
	WebElement quoteget = driver.findElement(By.name("getquote"));
	quoteget.click();
	
	Select droprestype = new Select(driver.findElement(By.name("restype")));
	droprestype.selectByVisibleText("Condo");
	
	WebElement add1 = driver.findElement(By.name("add1"));
	add1.sendKeys("111 Generic St");
	
	WebElement city = driver.findElement(By.name("city"));
	city.sendKeys("Townsville");
			
	WebElement state = driver.findElement(By.name("state"));
	state.sendKeys("Texas");
	
	WebElement zip = driver.findElement(By.name("zip"));
	zip.sendKeys("123456789");
	
	Select dropresuse = new Select(driver.findElement(By.name("resuse")));
	dropresuse.selectByVisibleText("Secondary");
	
	Thread.sleep(4000);
	
	WebElement sub = driver.findElement(By.name("sub"));
	sub.click();	
}

@And ("^I get a new quote - homeowner details$")
	public void Step_Five() throws InterruptedException {
	
	WebElement fname = driver.findElement(By.name("fname"));
	fname.sendKeys("John");
	
	WebElement lname = driver.findElement(By.name("lname"));
	lname.sendKeys("Doe");
	
	WebElement dob = driver.findElement(By.id("dob"));
	dob.sendKeys("01-01-1980");
	
	WebElement retired = driver.findElement(By.id("No"));
	retired.click();
		
	WebElement ssn = driver.findElement(By.name("ssn"));
	ssn.sendKeys("123456789");
	
	WebElement email = driver.findElement(By.name("email"));
	email.sendKeys("test@test.com");
	
	Thread.sleep(4000);
	
	WebElement sub = driver.findElement(By.name("sub"));
	sub.click();	
}


@And ("^I get a new quote - property details$")
	public void Step_Six() throws InterruptedException {
	
	WebElement value = driver.findElement(By.name("value"));
	value.sendKeys("200000");
	
	WebElement ybuilt = driver.findElement(By.name("ybuilt"));
	ybuilt.sendKeys("2000");
	
	WebElement sqft = driver.findElement(By.name("sqft"));
	sqft.sendKeys("2800");
	
	Select dstyle = new Select(driver.findElement(By.name("dstyle")));
	dstyle.selectByVisibleText("2 Stories");
	
	Select rmat = new Select(driver.findElement(By.name("rmat")));
	rmat.selectByVisibleText("Rubber");
	
	Select garage = new Select(driver.findElement(By.name("garage")));
	garage.selectByVisibleText("Basement");
	
	WebElement fbath = driver.findElement(By.name("fbath"));
	fbath.sendKeys("2");
	
	WebElement hbath = driver.findElement(By.name("hbath"));
	hbath.sendKeys("1");

	WebElement pool = driver.findElement(By.id("Yes"));
	pool.click();
	
	Thread.sleep(4000);
	
	WebElement sub = driver.findElement(By.name("sub"));
	sub.click();		
		
}

@And ("^I finalize and buy quote$")
	public void Step_Seven() throws InterruptedException {
	
	JavascriptExecutor jse = (JavascriptExecutor)driver;
	
	Thread.sleep(3000);
	
	WebElement details = driver.findElement(By.linkText("Additional Details"));
	details.click();
	
	Thread.sleep(2000);
	jse.executeScript("window.scrollBy(0,500)", "");
	Thread.sleep(2000);
	
	WebElement cont = driver.findElement(By.name("continue"));
	cont.click();
	
	Thread.sleep(2000);
	jse.executeScript("window.scrollBy(0,1000)", "");
	Thread.sleep(2000);
	
	WebElement sub = driver.findElement(By.name("sub"));
	sub.click();	
	
	Thread.sleep(3000);
	
	WebElement terms = driver.findElement(By.linkText("Please click and read terms and conditions before buying policy"));
	terms.click();
	
	Thread.sleep(2000);
	jse.executeScript("window.scrollBy(0,500)", "");
	Thread.sleep(2000);
	
	WebElement ret = driver.findElement(By.linkText("Continue to Buy Policy"));
	ret.click();
	
	WebElement check = driver.findElement(By.name("check"));
	check.click();
	
	WebElement startdate = driver.findElement(By.name("startdate"));
	startdate.sendKeys("04-15-2019");
	
	Thread.sleep(4000);
	
	WebElement sub2 = driver.findElement(By.name("sub"));
	sub2.click();
}

@And ("^I Logout")
	public void Step_Eight() throws InterruptedException {
	Thread.sleep(5000);
	
	WebElement logout = driver.findElement(By.linkText("Logout"));
	logout.click();

	Thread.sleep(2000);
	
}

@After 
	public void end() {
	driver.quit();
}
}
