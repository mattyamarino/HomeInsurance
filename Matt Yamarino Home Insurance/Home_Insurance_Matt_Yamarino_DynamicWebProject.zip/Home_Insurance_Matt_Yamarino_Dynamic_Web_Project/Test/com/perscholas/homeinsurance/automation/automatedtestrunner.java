package com.perscholas.homeinsurance.automation;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

import org.testng.annotations.Test;

@CucumberOptions(features = {"Test/com/perscholas/homeinsurance/automation"}, glue = {""})

@Test
public class automatedtestrunner extends AbstractTestNGCucumberTests{

}
