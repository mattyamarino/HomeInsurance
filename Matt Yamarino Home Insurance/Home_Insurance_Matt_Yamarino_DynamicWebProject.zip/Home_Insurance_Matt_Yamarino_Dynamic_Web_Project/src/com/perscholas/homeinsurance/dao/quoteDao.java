package com.perscholas.homeinsurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.perscholas.homeinsurance.model.quote;

public class quoteDao {  
	

//Method To Insert Into User Table	
public int insertQuote(quote quote) throws SQLException, ClassNotFoundException, IOException {  
	    Connection conn = null;
		oracleConnection oracle = new oracleConnection();
		PreparedStatement statement = null;  
		int t = 0;   
		ResultSet s = null;
		
		try {
		String sql = "INSERT INTO quote (location_Id, monthly_Premium, dwelling_Coverage, detatched_Structures, personal_Property, add_Living_Exp, medical_Expenses, deductable ) VALUES (?, ?, ? , ?, ?, ?,?,?)";  
		String[] qucol = {"quote_id"};  
		conn = oracle.getConnection();
	    statement = conn.prepareStatement(sql,qucol);   
	    statement.setInt(1, quote.getLocationId());
	    statement.setFloat(2, quote.getMonthlyPremium());
	    statement.setFloat(3, quote.getDwellingCoverage());
	    statement.setFloat(4, quote.getDetachedStructures()); 
	    statement.setFloat(5, quote.getPersonalProperty());
	    statement.setFloat(6, quote.getAddLivingExp());
	    statement.setFloat(7, quote.getMedicalExpenses());
	    statement.setFloat(8, quote.getDeductable());
	    statement.executeUpdate();
	    s = statement.getGeneratedKeys();
	    if (s != null && s.next())
	    {t = s.getInt(1);}
		}	
	    
	catch (ClassNotFoundException | IOException | SQLException e)
	{
		System.out.println("Error: " + e.getMessage());
		e.getStackTrace();
	}

	finally {	
		if (conn != null) {conn.close();}
	if (statement != null) {statement.close();}
	if (s != null) {s.close();}
	}

System.out.println(t);
return t;
	}	


//Method To Get All Data From User Table
	public List<quote> getAllQuotes() throws SQLException {  
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		quote u = null;   
		List<quote> quoteList = null;  
		
		String querry = "SELECT * FROM quote ORDER BY quote_id";  
		
		oracleConnection oracle = new oracleConnection();
		
		try {
			
			conn = oracle.getConnection();
			System.out.println("connection working");
			stmt = conn.createStatement();
			rs = stmt.executeQuery(querry);
			quoteList = new ArrayList<quote>(); 
			
			while (rs.next()) {
				
				u = new quote();  
				u.setQuoteId(rs.getInt(1));  
				u.setLocationId(rs.getInt(2));
				u.setMonthlyPremium(rs.getFloat(3));
				u.setDwellingCoverage(rs.getFloat(4));
				u.setDetachedStructures(rs.getFloat(5));
				u.setPersonalProperty(rs.getFloat(6));
				u.setAddLivingExp(rs.getFloat(7));
				u.setMedicalExpenses(rs.getFloat(8));
				u.setDeductable(rs.getFloat(9));
				quoteList.add(u); 
			
			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return quoteList; 
			
	}
	
	public quote getQByUID(int uid) throws SQLException {
	    Connection conn = null;
	    PreparedStatement stmt = null;
	    ResultSet rs = null;
	    quote u = null;
	    String query = "SELECT * FROM quote WHERE location_id = ? AND rownum < 2";
	    oracleConnection oracle = new oracleConnection();
	    
	    try
	    {
	        conn = oracle.getConnection();
	        stmt = conn.prepareStatement(query);
	        stmt.setInt(1, uid);
	        rs = stmt.executeQuery();
	        
	        
	        if(rs.next()) {
	        	u = new quote();  
				u.setQuoteId(rs.getInt(1));  
				u.setLocationId(rs.getInt(2));
				u.setMonthlyPremium(rs.getFloat(3));
				u.setDwellingCoverage(rs.getFloat(4));
				u.setDetachedStructures(rs.getFloat(5));
				u.setPersonalProperty(rs.getFloat(6));
				u.setAddLivingExp(rs.getFloat(7));
				u.setMedicalExpenses(rs.getFloat(8));
				u.setDeductable(rs.getFloat(9));
	        }
	    }
	    catch (ClassNotFoundException | IOException | SQLException e)
	    {
	        // TODO Auto-generated catch block
	    	System.out.println("Error: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	    	if(rs != null) {
	        rs.close();}
	    	
	        if(stmt != null) {
	            stmt.close();
	        }
	        if(conn != null) {
	            conn.close();
	        }
	    }
	    return u;
	}
	
}
		
	