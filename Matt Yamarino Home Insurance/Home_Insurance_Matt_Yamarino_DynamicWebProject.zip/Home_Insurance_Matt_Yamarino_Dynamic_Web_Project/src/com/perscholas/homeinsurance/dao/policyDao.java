package com.perscholas.homeinsurance.dao;



import java.io.IOException;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.perscholas.homeinsurance.bo.locationBo;
import com.perscholas.homeinsurance.model.location;
import com.perscholas.homeinsurance.model.policy;


 

public class policyDao {  
	
	//Method To Insert Into policy Table
	public int insertPolicy(policy policy) throws SQLException, ClassNotFoundException, IOException {  
		    Connection conn = null; 
			oracleConnection oracle = new oracleConnection();
			int t = 0;   
			ResultSet s = null;
			PreparedStatement statement = null;
			
			try {
			String sql = "INSERT INTO policy (quote_id, user_id, effective_date, end_date, term) VALUES (?, ?, ?,?,?)";  
			String[] polcol = {"policy_id"};  
			conn = oracle.getConnection();
		    statement = conn.prepareStatement(sql,polcol);   //change all the way down
		    statement.setInt(1, policy.getQuoteId());
		    statement.setInt(2,  policy.getUserId());
		    statement.setDate(3, java.sql.Date.valueOf(policy.getEffectiveDate().toString()));
		    statement.setDate(4, java.sql.Date.valueOf(policy.getEndDate().toString()));
		    statement.setInt(5, policy.getTerm());
		    statement.executeUpdate();
		    s = statement.getGeneratedKeys();
		    if (s != null && s.next())
		    {t = s.getInt(1);}
			}
		    
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}

		finally {	
			if (conn != null) {conn.close();}
		if (statement != null) {statement.close();}
		if (s != null) {s.close();}
		}
	System.out.println(t);
	return t;
		}	
		

	//Method To Get All Data From Policy Table
	public List<policy> getAllPolicies() throws SQLException {  
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		policy u = null;   
		List<policy> policyList = null;  
		
		String querry = "SELECT * FROM policy ORDER BY policy_id";  
		oracleConnection oracle = new oracleConnection();
		
		try {
			
			conn = oracle.getConnection();
			System.out.println("connection working");
			stmt = conn.createStatement();
			rs = stmt.executeQuery(querry);
			policyList = new ArrayList<policy>();  
			
			while (rs.next()) {
				
				u = new policy();  	
				u.setPolicyId(rs.getInt(1));  
				u.setQuoteId(rs.getInt(2));
				u.setUserId(rs.getInt(3));
				u.setEffectiveDate(rs.getDate(4).toLocalDate());
				u.setEndDate(rs.getDate(5).toLocalDate());
				u.setTerm(rs.getInt(6));
				u.setPolicyStatus(rs.getString(7));
				
				policyList.add(u); 
			
			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return policyList; 
			
		}
	
	
	public policy getPolicybyId(int id) throws SQLException {
	    Connection conn = null;
	    PreparedStatement stmt = null;
	    ResultSet rs = null;
	    policy u = null;
	    String query = "SELECT * FROM policy WHERE policy_id = ? AND rownum < 2";
	    oracleConnection oracle = new oracleConnection();
	    
	    try
	    {
	        conn = oracle.getConnection();
	        stmt = conn.prepareStatement(query);
	        stmt.setInt(1, id);
	        rs = stmt.executeQuery();
	        
	        
	        if(rs.next()) {
	        	u = new policy();  	
				u.setPolicyId(rs.getInt(1));  
				u.setQuoteId(rs.getInt(2));
				u.setUserId(rs.getInt(3));
				u.setEffectiveDate(rs.getDate(4).toLocalDate());
				u.setEndDate(rs.getDate(5).toLocalDate());
				u.setTerm(rs.getInt(6));
				u.setPolicyStatus(rs.getString(7));
	        }
	    }
	    catch (ClassNotFoundException | IOException | SQLException e)
	    {
	        // TODO Auto-generated catch block
	    	System.out.println("Error: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	    	if(rs != null) {
	        rs.close();}
	    	
	        if(stmt != null) {
	            stmt.close();
	        }
	        if(conn != null) {
	            conn.close();
	        }
	    }
	    return u;
	}
	
	public List<policy> getPolicybyUserId(int id) throws SQLException {
	    Connection conn = null;
	    PreparedStatement stmt = null;
	    ResultSet rs = null;
	    policy u = null;
	    String query = "SELECT * FROM policy WHERE user_id = ?";
	    oracleConnection oracle = new oracleConnection();
	    List<policy> plist;
	    plist = new ArrayList<policy>();
	    
	    try
	    {
	        conn = oracle.getConnection();
	        stmt = conn.prepareStatement(query);
	        stmt.setInt(1, id);
	        rs = stmt.executeQuery();
	        
	        
	        if(rs.next()) {
	        	u = new policy();  	
				u.setPolicyId(rs.getInt(1));  
				u.setQuoteId(rs.getInt(2));
				u.setUserId(rs.getInt(3));
				u.setEffectiveDate(rs.getDate(4).toLocalDate());
				u.setEndDate(rs.getDate(5).toLocalDate());
				u.setTerm(rs.getInt(6));
				u.setPolicyStatus(rs.getString(7));
				
				plist.add(u);
	        }
	    }
	    catch (ClassNotFoundException | IOException | SQLException e)
	    {
	        // TODO Auto-generated catch block
	    	System.out.println("Error: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	    	if(rs != null) {
	        rs.close();}
	    	
	        if(stmt != null) {
	            stmt.close();
	        }
	        if(conn != null) {
	            conn.close();
	        }
	    }
	    return plist;
	}
	


	
	public void updatePolicy(policy policy) throws SQLException, ClassNotFoundException, IOException {  
	    Connection conn = null; 
		oracleConnection oracle = new oracleConnection(); 
		PreparedStatement statement = null;
		
		try {
		String sql = "UPDATE policy SET end_date = ? , policy_status = ? WHERE policy_id = ?";    
		conn = oracle.getConnection();
	    statement = conn.prepareStatement(sql);   
	    statement.setDate(1, java.sql.Date.valueOf(policy.getEndDate().toString()));
	    statement.setString(2, policy.getPolicyStatus());
	    statement.setInt(3, policy.getPolicyId());
	    statement.executeUpdate();
	
		}
	    
	catch (ClassNotFoundException | IOException | SQLException e)
	{
		System.out.println("Error: " + e.getMessage());
		e.getStackTrace();
	}

	finally {	
		if (conn != null) {conn.close();}
	if (statement != null) {statement.close();}
	}
	}
		
	
		public void deleteTestData(int uid) throws SQLException, ClassNotFoundException, IOException {  
		    Connection conn = null; 
			oracleConnection oracle = new oracleConnection(); 
			PreparedStatement statement1 = null;
			PreparedStatement statement2 = null;
			PreparedStatement statement3 = null;
			PreparedStatement statement4 = null;
			PreparedStatement statement5 = null;
			PreparedStatement statement6 = null;
			
			locationBo lbo = new locationBo();
			location l = lbo.getLocByUId(uid);
			int lid = l.getLocationId();
			
			try {
			conn = oracle.getConnection();
			
			String sql1 = "delete from policy where user_id = ?";  
		    statement1 = conn.prepareStatement(sql1);   
		    statement1.setInt(1, uid);
		    statement1.executeUpdate();
		    
		    String sql2 = "delete from homeowner where user_id = ?";
		    statement2 = conn.prepareStatement(sql2);
		    statement2.setInt(1, uid);
		    statement2.executeUpdate();
		    
		    String sql3 = "delete from quote where location_id = ?";
		    statement3 = conn.prepareStatement(sql3);
		    statement3.setInt(1, lid);
		    statement3.executeUpdate();
		    
		    String sql4 = "delete from properties where location_id = ?";
		    statement4 = conn.prepareStatement(sql4);
		    statement4.setInt(1, lid);
		    statement4.executeUpdate();
		    
		    String sql5 = "delete from location where user_id = ?";
		    statement5 = conn.prepareStatement(sql5);
		    statement5.setInt(1, uid);
		    statement5.executeUpdate();
		    
		    String sql6 = "delete from user1 where user_id = ?";
		    statement6 = conn.prepareStatement(sql6);
		    statement6.setInt(1, uid);
		    statement6.executeUpdate();
		
			}
		    
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}

		finally {	
			if (conn != null) {conn.close();}
		if (statement1 != null) {statement1.close();}
		if (statement2 != null) {statement2.close();}
		if (statement3 != null) {statement3.close();}
		if (statement4 != null) {statement4.close();}
		if (statement5 != null) {statement5.close();}
		if (statement6 != null) {statement6.close();}
		}	

	}	
		
}