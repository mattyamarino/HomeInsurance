package com.perscholas.homeinsurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.perscholas.homeinsurance.model.user1;




public class userDao {  
	
//Method To Insert Into User Table	
public int insertUser(user1 user) throws SQLException, ClassNotFoundException, IOException {  //change three times
	    Connection conn = null; 
		oracleConnection oracle = new oracleConnection();
		int t = 0;   
		ResultSet s = null;
		PreparedStatement statement = null;
		
		try {
		String sql = "INSERT INTO user1 (user_name, password, admin_role) VALUES (?, ?, ?)";  //big changes
		String[] uidcol = {"user_id"};  //change
		conn = oracle.getConnection();
	    statement = conn.prepareStatement(sql,uidcol);   //change all the way down
	    statement.setString(1, user.getUserName());
	    statement.setString(2, user.getUserPassword());
	    statement.setString(3, user.getAdminRole());
	    statement.executeUpdate();
	    s = statement.getGeneratedKeys();
	    if (s != null && s.next())
	    {t = s.getInt(1);}
		}
	    
	catch (ClassNotFoundException | IOException | SQLException e)
	{
		System.out.println("Error: " + e.getMessage());
		e.getStackTrace();
	}

	finally {	
		if (conn != null) {conn.close();}
	if (statement != null) {statement.close();}
	if (s != null) {s.close();}
	}
System.out.println(t);
return t;
	}	
	

//Method To Get All Data From User Table
public List<user1> getAllUsers() throws SQLException {
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		user1 u = null;   
		List<user1> userList = null;  
		String querry = "SELECT * FROM user1 ORDER BY user_id";  
		oracleConnection oracle = new oracleConnection();
		
		try {
			conn = oracle.getConnection();
			System.out.println("connection working");
			stmt = conn.createStatement();
			rs = stmt.executeQuery(querry);
			userList = new ArrayList<user1>();  
			
			while (rs.next()) {
				u = new user1();  
				u.setUserId(rs.getInt(1));  
				u.setUserName(rs.getString(2));
				u.setUserPassword(rs.getString(3));
				u.setAdminRole(rs.getString(4));
				userList.add(u);
			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return userList;
			
		}
	

public user1 getUserbyUname(String uname) throws SQLException {
    Connection conn = null;
    PreparedStatement stmt = null;
    ResultSet result = null;
    user1 u = null;
    String query = "SELECT * FROM USER1 WHERE user_name = ?";
    oracleConnection oracle = new oracleConnection();
    
    try
    {
        conn = oracle.getConnection();
        stmt = conn.prepareStatement(query);
        stmt.setString(1, uname);
        result = stmt.executeQuery();
        
        
        if(result.next()) {
            u = new user1(result.getInt(1), result.getString(2), result.getString(3), result.getString(4));
        }
    }
    catch (ClassNotFoundException | IOException | SQLException e)
    {
        // TODO Auto-generated catch block
    	System.out.println("Error: " + e.getMessage());
        e.printStackTrace();
    } finally {
    	if(result != null) {
        result.close();}
    	
        if(stmt != null) {
            stmt.close();
        }
        if(conn != null) {
            conn.close();
        }
    }
    return u;
}


public user1 getUserbyId(int uid) throws SQLException {
    Connection conn = null;
    PreparedStatement stmt = null;
    ResultSet result = null;
    user1 u = null;
    String query = "SELECT * FROM USER1 WHERE user_id = ?";
    oracleConnection oracle = new oracleConnection();
    
    try
    {
        conn = oracle.getConnection();
        stmt = conn.prepareStatement(query);
        stmt.setInt(1, uid);
        result = stmt.executeQuery();
        
        
        if(result.next()) {
            u = new user1(result.getInt(1), result.getString(2), result.getString(3), result.getString(4));
        }
    }
    catch (ClassNotFoundException | IOException | SQLException e)
    {
        // TODO Auto-generated catch block
    	System.out.println("Error: " + e.getMessage());
        e.printStackTrace();
    } finally {
    	if(result != null) {
        result.close();}
    	
        if(stmt != null) {
            stmt.close();
        }
        if(conn != null) {
            conn.close();
        }
    }
    return u;
}

}



