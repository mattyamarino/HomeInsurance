package com.perscholas.homeinsurance.dao;



import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.perscholas.homeinsurance.model.properties;



public class propertiesDao {  
	
	//Method To Insert Into Properties Table	
	public boolean insertProperties(properties properties) throws SQLException, ClassNotFoundException, IOException {  
		    Connection conn = null; 
			oracleConnection oracle = new oracleConnection();
			boolean boo = true;
			PreparedStatement statement = null;
			try {
			String sql = "INSERT INTO properties (location_Id, market_Value, year_Built, square_Footage, dwelling_Type, roof_Material, garage_Type, full_Baths, half_Baths, pool) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";                                                                                                     
			conn = oracle.getConnection();
		    statement = conn.prepareStatement(sql);   
		    statement.setInt(1, properties.getLocationId());
		    statement.setFloat(2, properties.getMarketValue());
		    statement.setInt(3, properties.getYearBuilt());
		    statement.setInt(4, properties.getSquareFootage());
		    statement.setString(5, properties.getDwellingType());
		    statement.setString(6, properties.getRoofMaterial());
		    statement.setString(7, properties.getGarageType());
		    statement.setInt(8, properties.getFullBaths());
		    statement.setInt(9,  properties.getHalfBaths());
		    
		    String pool;
		    if (properties.isPool() == true) {pool = "Yes";}
		    else {pool = "No";}
		    statement.setString(10, pool);   
		    
		    statement.executeUpdate();
			}
		
		    
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
			boo = false;
		}

		finally {	
			if (conn != null) {conn.close();}
		if (statement != null) {statement.close();}
		}
	System.out.println(boo);
	return boo;
		}	

	
	
	//Method To Get All Data From Properties Table
	public List<properties> getAllProperties() throws SQLException {  
		
		Connection conn = null;
		Statement stmt = null; 
		ResultSet rs = null;
		properties u = null;   
		List<properties> propertiesList = null;  
		String querry = "SELECT * FROM properties ORDER BY location_id";  
		oracleConnection oracle = new oracleConnection();
		
		try {
			
			conn = oracle.getConnection();
			System.out.println("connection working");
			stmt = conn.createStatement();
			rs = stmt.executeQuery(querry);
			propertiesList = new ArrayList<properties>();  //change list and object
			
			while (rs.next()) {
				u = new properties();  
				u.setLocationId(rs.getInt(1));  
				u.setMarketValue(rs.getFloat(2));
				u.setYearBuilt(rs.getInt(3));
				u.setSquareFootage(rs.getInt(4));
				u.setDwellingType(rs.getString(5));
				u.setRoofMaterial(rs.getString(6));
				u.setGarageType(rs.getString(7));
				u.setFullBaths(rs.getInt(8));
				u.setHalfBaths(rs.getInt(9));
				String a = rs.getString(10);
				if (a == "yes") {u.setPool(true);}
				else {u.setPool(false);}
				propertiesList.add(u); 
			
			
			}
			}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return propertiesList; 
			
		}
	
	
	public properties getPropByLID(int uid) throws SQLException {
	    Connection conn = null;
	    PreparedStatement stmt = null;
	    ResultSet rs = null;
	    properties u = null;
	    String query = "SELECT * FROM properties WHERE location_id = ? AND rownum < 2";
	    oracleConnection oracle = new oracleConnection();
	    
	    try
	    {
	        conn = oracle.getConnection();
	        stmt = conn.prepareStatement(query);
	        stmt.setInt(1, uid);
	        rs = stmt.executeQuery();
	        
	        
	        if(rs.next()) {
	        	u = new properties();  
				u.setLocationId(rs.getInt(1));  
				u.setMarketValue(rs.getFloat(2));
				u.setYearBuilt(rs.getInt(3));
				u.setSquareFootage(rs.getInt(4));
				u.setDwellingType(rs.getString(5));
				u.setRoofMaterial(rs.getString(6));
				u.setGarageType(rs.getString(7));
				u.setFullBaths(rs.getInt(8));
				u.setHalfBaths(rs.getInt(9));
				String a = rs.getString(10);
				if (a == "yes") {u.setPool(true);}
				else {u.setPool(false);}
	        }
	    }
	    catch (ClassNotFoundException | IOException | SQLException e)
	    {
	        // TODO Auto-generated catch block
	    	System.out.println("Error: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	    	if(rs != null) {
	        rs.close();}
	    	
	        if(stmt != null) {
	            stmt.close();
	        }
	        if(conn != null) {
	            conn.close();
	        }
	    }
	    return u;
	}
}
		
	