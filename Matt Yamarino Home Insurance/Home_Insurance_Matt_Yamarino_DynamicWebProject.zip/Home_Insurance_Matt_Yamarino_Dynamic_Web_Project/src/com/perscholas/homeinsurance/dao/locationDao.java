package com.perscholas.homeinsurance.dao;



import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.perscholas.homeinsurance.model.location;


public class locationDao {  
	
	//Method To Insert Into User Table	
	public int insertLocation(location location) throws SQLException, ClassNotFoundException, IOException {  
		    Connection conn = null;  
			oracleConnection oracle = new oracleConnection();
			int t = 0;   
			ResultSet s = null;
			PreparedStatement statement = null;
			
			try {
			String sql = "INSERT INTO location (user_Id, residence_Type, address_Line_1, address_Line_2, city, location_State, zip_Code, residence_Use) VALUES (?, ?, ?,?, ?,?,?,?)";  
			String[] lidcol = {"location_id"};  
			conn = oracle.getConnection();
		    statement = conn.prepareStatement(sql,lidcol);   
		    statement.setInt(1, location.getUserId());
		    statement.setString(2, location.getResidenceType());
		    statement.setString(3,  location.getAddressLine1());
		    statement.setString(4, location.getAddressLine2());
		    statement.setString(5,  location.getCity());
		    statement.setString(6, location.getLocationState());
		    statement.setInt(7, location.getZipCode());
		    statement.setString(8, location.getResidenceUse());
		    
		   
		    statement.executeUpdate();
		    s = statement.getGeneratedKeys();
		    if (s != null && s.next())
		    {t = s.getInt(1);}
			}
		    
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}

		finally {	
			if (conn != null) {conn.close();}
		if (statement != null) {statement.close();}
		if (s != null) {s.close();}
		}
	System.out.println(t);
	return t;
		}	
	
	public List<location> getAllLocations() throws SQLException {  
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		location u = null;   
		List<location> locationList = null;  
		
		String querry = "SELECT * FROM location ORDER BY location_id"; 
		
		oracleConnection oracle = new oracleConnection();
		
		try {
			conn = oracle.getConnection();
			System.out.println("connection working");
			stmt = conn.createStatement();
			rs = stmt.executeQuery(querry);
			locationList = new ArrayList<location>();  
			
			while (rs.next()) {
				
				u = new location();  
				
				u.setLocationId(rs.getInt(1));  
				u.setUserId(rs.getInt(2));
				u.setResidenceType(rs.getString(3));
				u.setAddressLine1(rs.getString(4));
				u.setAddressLine2(rs.getString(5));
				u.setCity(rs.getString(6));
				u.setLocationState(rs.getString(7));
				u.setZipCode(rs.getInt(8));
				u.setResidenceUse(rs.getString(9));
				
				locationList.add(u); 
			
			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return locationList; 
			
		}
	
	public location getLocByUID(int uid) throws SQLException {
	    Connection conn = null;
	    PreparedStatement stmt = null;
	    ResultSet rs = null;
	    location u = null;
	    String query = "SELECT * FROM location WHERE user_id = ? AND rownum < 2";
	    oracleConnection oracle = new oracleConnection();
	    
	    try
	    {
	        conn = oracle.getConnection();
	        stmt = conn.prepareStatement(query);
	        stmt.setInt(1, uid);
	        rs = stmt.executeQuery();
	        
	        
	        if(rs.next()) {
	        	u = new location();  
				
				u.setLocationId(rs.getInt(1));  
				u.setUserId(rs.getInt(2));
				u.setResidenceType(rs.getString(3));
				u.setAddressLine1(rs.getString(4));
				u.setAddressLine2(rs.getString(5));
				u.setCity(rs.getString(6));
				u.setLocationState(rs.getString(7));
				u.setZipCode(rs.getInt(8));
				u.setResidenceUse(rs.getString(9));
	        }
	    }
	    catch (ClassNotFoundException | IOException | SQLException e)
	    {
	        // TODO Auto-generated catch block
	    	System.out.println("Error: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	    	if(rs != null) {
	        rs.close();}
	    	
	        if(stmt != null) {
	            stmt.close();
	        }
	        if(conn != null) {
	            conn.close();
	        }
	    }
	    return u;
	}
	
				
		}	

