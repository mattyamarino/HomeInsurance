package com.perscholas.homeinsurance.dao;



import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.perscholas.homeinsurance.model.homeOwner;


public class homeOwnerDao {  
	
	//Method To Insert Into Homeowner Table	
	public boolean insertHomeOwner(homeOwner homeOwner) throws SQLException, ClassNotFoundException, IOException {  
		    Connection conn = null; 
			oracleConnection oracle = new oracleConnection();
			boolean boo = true;
			ResultSet s = null;
			PreparedStatement statement = null;
			
			try {
				
			String sql = "INSERT INTO homeowner (user_id,first_name,last_name,dob,retired_status,ssn,email) VALUES (?,?,?,?,?,?,?)";                                                                
			conn = oracle.getConnection();
		    statement = conn.prepareStatement(sql);   
		    statement.setInt(1, homeOwner.getUserId());
		    statement.setString(2,homeOwner.getFirstName() );
		    statement.setString(3,homeOwner.getLastName() );
		    statement.setDate(4,java.sql.Date.valueOf(homeOwner.getDateOfBirth().toString()));
		    
		    String ret;
		    if (homeOwner.isRetired() == true) {ret = "Yes";}
		    else {ret = "No";}
		    statement.setString(5, ret);   
		    
		    statement.setInt(6,homeOwner.getSsn());
		    statement.setString(7,homeOwner.getEmail() );
		    statement.executeUpdate();
		    
		
			}
		    
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
			boo = false;
		}

		finally {	
			if (conn != null) {conn.close();}
		if (statement != null) {statement.close();}
		if (s != null) {s.close();}
		}
	System.out.println(boo);
	return boo;
		}	
		

	//Method To Get All Data From Homeowner Table
	public List<homeOwner> getAllHomeOwners() throws SQLException {  
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		homeOwner u = null;   
		List<homeOwner> homeOwnerList = null;  
		String querry = "SELECT * FROM homeowner ORDER BY user_id";  
		oracleConnection oracle = new oracleConnection();
		
		try {
			conn = oracle.getConnection();
			System.out.println("connection working");
			stmt = conn.createStatement();
			rs = stmt.executeQuery(querry);
			homeOwnerList = new ArrayList<homeOwner>();  
			
			while (rs.next()) {
				
				u = new homeOwner();  
				u.setUserId(rs.getInt(1));  
				u.setFirstName(rs.getString(2));
				u.setLastName(rs.getString(3));
				u.setDateOfBirth(rs.getDate(4).toLocalDate());
				String a = rs.getString(5);
				if (a == "yes") {u.setRetired(true);}
				else {u.setRetired(false);}
				u.setSsn(rs.getInt(6));
				u.setEmail(rs.getString(7));
				
				
				
				homeOwnerList.add(u); 
			
			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return homeOwnerList; 
			
		}
	
	
	public homeOwner getHOByUID(int uid) throws SQLException {
	    Connection conn = null;
	    PreparedStatement stmt = null;
	    ResultSet rs = null;
	    homeOwner u = null;
	    String query = "SELECT * FROM homeowner WHERE user_id = ? AND rownum < 2";
	    oracleConnection oracle = new oracleConnection();
	    
	    try
	    {
	        conn = oracle.getConnection();
	        stmt = conn.prepareStatement(query);
	        stmt.setInt(1, uid);
	        rs = stmt.executeQuery();
	        
	        
	        if(rs.next()) {
	        	u = new homeOwner();  
				u.setUserId(rs.getInt(1));  
				u.setFirstName(rs.getString(2));
				u.setLastName(rs.getString(3));
				u.setDateOfBirth(rs.getDate(4).toLocalDate());
				String a = rs.getString(5);
				if (a == "yes") {u.setRetired(true);}
				else {u.setRetired(false);}
				u.setSsn(rs.getInt(6));
				u.setEmail(rs.getString(7));
	        }
	    }
	    catch (ClassNotFoundException | IOException | SQLException e)
	    {
	        // TODO Auto-generated catch block
	    	System.out.println("Error: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	    	if(rs != null) {
	        rs.close();}
	    	
	        if(stmt != null) {
	            stmt.close();
	        }
	        if(conn != null) {
	            conn.close();
	        }
	    }
	    return u;
	}
	
}	

