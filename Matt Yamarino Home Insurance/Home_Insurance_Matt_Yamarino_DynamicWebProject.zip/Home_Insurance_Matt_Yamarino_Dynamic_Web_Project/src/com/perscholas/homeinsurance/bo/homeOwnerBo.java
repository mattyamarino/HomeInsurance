package com.perscholas.homeinsurance.bo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.perscholas.homeinsurance.dao.homeOwnerDao;
import com.perscholas.homeinsurance.model.homeOwner;

public class homeOwnerBo {

	public List<homeOwner> fetchAllHomeOwners() throws SQLException {
		
			homeOwnerDao homeDao = new homeOwnerDao();
			List<homeOwner> homeList = homeDao.getAllHomeOwners();
		
		return homeList;
		} 

	public void addHomeOwner(homeOwner home) throws ClassNotFoundException, IOException, SQLException {
			homeOwnerDao homeDao = new homeOwnerDao();
			homeDao.insertHomeOwner(home); 
		}
	
	public homeOwner getHOByUId(int id) throws SQLException {
		homeOwnerDao dao = new homeOwnerDao();
		homeOwner u = new homeOwner();
		u = dao.getHOByUID(id);
		return u;
	}
}
