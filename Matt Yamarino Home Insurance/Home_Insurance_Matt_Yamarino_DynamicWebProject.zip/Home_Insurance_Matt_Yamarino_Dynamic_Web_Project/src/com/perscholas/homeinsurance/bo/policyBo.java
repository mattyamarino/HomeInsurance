package com.perscholas.homeinsurance.bo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.perscholas.homeinsurance.dao.policyDao;
import com.perscholas.homeinsurance.model.policy;



public class policyBo {

	public List<policy> fetchAllPolicies() throws SQLException {
	
			policyDao policyDao = new policyDao();
			List<policy> policyList; 
			policyList = new ArrayList<policy>();
			policyList = policyDao.getAllPolicies();
			return policyList;
	
		} 

	public int addPolicy(policy policy) throws ClassNotFoundException, IOException, SQLException {
			policyDao policyDao = new policyDao();
			int x = policyDao.insertPolicy(policy);
			return x;
		}

	public policy getPolicyById(int id) throws SQLException {
		policyDao dao = new policyDao();
		policy u = new policy();
		u = dao.getPolicybyId(id);
		return u;
	}
	
	public List<policy> getPolicyByUserId(int uid) throws SQLException {
		policyDao dao = new policyDao();
		List<policy> policyList; 
		policyList = new ArrayList<policy>();
		policyList = dao.getPolicybyUserId(uid);
		return policyList;
		
	}
	
	public void updatePolicy(policy policy) throws ClassNotFoundException, SQLException, IOException {
		policyDao dao = new policyDao();
		dao.updatePolicy(policy);
	}
	
	public void deleteTestData (int uid) throws ClassNotFoundException, SQLException, IOException {
		policyDao dao = new policyDao();
		dao.deleteTestData(uid);
	}

	
}
