package com.perscholas.homeinsurance.bo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.perscholas.homeinsurance.dao.locationDao;
import com.perscholas.homeinsurance.model.location;




public class locationBo {
	
	public List<location> fetchAllLocations() throws SQLException {
	
			locationDao locationDao = new locationDao();
			List<location> locationList;
			locationList = new ArrayList<location>();
			locationList = locationDao.getAllLocations();
			return locationList;
			                                       	

		}
	
	public int addLocation(location location) throws ClassNotFoundException, IOException, SQLException {
			locationDao locationDao = new locationDao();
			int x = locationDao.insertLocation(location);
			return x;
		}

	
	public location getLocByUId(int id) throws SQLException {
		locationDao dao = new locationDao();
		location u = new location();
		u = dao.getLocByUID(id);
		return u;
	}
}
