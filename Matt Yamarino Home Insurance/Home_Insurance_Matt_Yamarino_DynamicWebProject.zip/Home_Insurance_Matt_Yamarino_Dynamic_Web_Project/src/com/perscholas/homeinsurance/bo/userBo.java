package com.perscholas.homeinsurance.bo;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;


import com.perscholas.homeinsurance.dao.userDao;
import com.perscholas.homeinsurance.model.user1;

public class userBo {
	
public List<user1> fetchAllUsers() throws SQLException {

		userDao userDao = new userDao();
		List<user1> userList = userDao.getAllUsers();
		return userList;
	} 

public void addUser(user1 user) throws ClassNotFoundException, IOException, SQLException {
		userDao userDao = new userDao();
		userDao.insertUser(user); 
	}

public user1 getUserbyUname(String uname) throws SQLException {
	userDao userDao = new userDao();
	user1 u = new user1();
	u = userDao.getUserbyUname(uname);
	return u;
}

public user1 getUserbyUID(int uid) throws SQLException {
	userDao userDao = new userDao();
	user1 u = new user1();
	u = userDao.getUserbyId(uid);
	return u;
}

	

}	
