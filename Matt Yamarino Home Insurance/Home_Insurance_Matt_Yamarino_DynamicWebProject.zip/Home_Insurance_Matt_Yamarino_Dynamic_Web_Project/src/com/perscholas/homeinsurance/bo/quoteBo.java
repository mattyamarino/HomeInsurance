package com.perscholas.homeinsurance.bo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.perscholas.homeinsurance.dao.quoteDao;
import com.perscholas.homeinsurance.model.quote;

public class quoteBo {

	public int addQuote(quote quote) throws ClassNotFoundException, IOException, SQLException {
			quoteDao quoteDao = new quoteDao();
			int x = quoteDao.insertQuote(quote);
			return x;
		} 
	
		
public List<quote> fetchAllQuotes() throws SQLException {
		

				quoteDao quoteDao = new quoteDao();
				List<quote> quoteList;
				quoteList = new ArrayList<quote>();
				quoteList = quoteDao.getAllQuotes();
				return quoteList;
}	
			


public quote getQuoteByUId(int id) throws SQLException {
	quoteDao dao = new quoteDao();
	quote u = new quote();
	u = dao.getQByUID(id);
	return u;
}

	
}
