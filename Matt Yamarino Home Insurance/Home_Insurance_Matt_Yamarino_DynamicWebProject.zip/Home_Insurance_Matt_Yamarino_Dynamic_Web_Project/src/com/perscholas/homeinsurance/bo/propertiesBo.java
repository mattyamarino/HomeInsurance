package com.perscholas.homeinsurance.bo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.perscholas.homeinsurance.dao.propertiesDao;
import com.perscholas.homeinsurance.model.properties;



public class propertiesBo {

	public List<properties> fetchAllProperties() throws SQLException {
	
			propertiesDao propDao = new propertiesDao();
			List<properties> propList = propDao.getAllProperties();
			 
			return propList;
		} 

	public void addProp(properties properties) throws ClassNotFoundException, IOException, SQLException {
			propertiesDao propDao = new propertiesDao();
			propDao.insertProperties(properties);
		}

	
	public properties getPropByLId(int id) throws SQLException {
		propertiesDao dao = new propertiesDao();
		properties u = new properties();
		u = dao.getPropByLID(id);
		return u;
	}
	
}
