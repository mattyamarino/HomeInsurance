package com.perscholas.homeinsurance.model;


import java.time.LocalDate;

public class homeOwner {
	
	//Attributes
	private int userId;
	private String firstName;
	private String lastName;
	private LocalDate dateOfBirth;
	private boolean retired;
	private int ssn;
	private String email;
	
	//Constructors
	public homeOwner() {}
	
	
	public homeOwner(int userId) {
		super();
		this.userId = userId;
	}


	public homeOwner(int userId, String firstName, String lastName, LocalDate dateOfBirth, boolean retired, int ssn,
			String email) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.retired = retired;
		this.ssn = ssn;
		this.email = email;
	}
	
	//Getters and Setters
	


	


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public boolean isRetired() {
		return retired;
	}


	public void setRetired(boolean retired) {
		this.retired = retired;
	}


	public int getSsn() {
		return ssn;
	}


	public void setSsn(int i) {
		this.ssn = i;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}

}
