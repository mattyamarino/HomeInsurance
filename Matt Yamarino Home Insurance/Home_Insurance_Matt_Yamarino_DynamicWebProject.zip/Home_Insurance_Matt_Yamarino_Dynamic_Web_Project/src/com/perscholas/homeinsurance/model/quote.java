package com.perscholas.homeinsurance.model;

public class quote {
	
	//Attributes
	private int quoteId;
	private int locationId;
	private float monthlyPremium;
	private float dwellingCoverage;
	private float detachedStructures;
	private float personalProperty;
	private float addLivingExp;
	private float medicalExpenses;
	private float deductable;
	
	
	//Constructors
	public quote() {}

 
	public quote(int locationId, float monthlyPremium, float dwellingCoverage, float detachedStructures,
			float personalProperty, float addLivingExp, float medicalExpenses, float deductable) {
		super();
		this.locationId = locationId;
		this.monthlyPremium = monthlyPremium;
		this.dwellingCoverage = dwellingCoverage;
		this.detachedStructures = detachedStructures;
		this.personalProperty = personalProperty;
		this.addLivingExp = addLivingExp;
		this.medicalExpenses = medicalExpenses;
		this.deductable = deductable;
	}

//Getters and Setters
	public int getQuoteId() {
		return quoteId;
	}


	public void setQuoteId(int quoteId) {
		this.quoteId = quoteId;
	}


	public int getLocationId() {
		return locationId;
	}


	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}


	public float getMonthlyPremium() {
		return monthlyPremium;
	}


	public void setMonthlyPremium(float monthlyPremium) {
		this.monthlyPremium = monthlyPremium;
	}


	public float getDwellingCoverage() {
		return dwellingCoverage;
	}


	public void setDwellingCoverage(float dwellingCoverage) {
		this.dwellingCoverage = dwellingCoverage;
	}


	public float getDetachedStructures() {
		return detachedStructures;
	}


	public void setDetachedStructures(float detachedStructures) {
		this.detachedStructures = detachedStructures;
	}


	public float getPersonalProperty() {
		return personalProperty;
	}


	public void setPersonalProperty(float personalProperty) {
		this.personalProperty = personalProperty;
	}


	public float getAddLivingExp() {
		return addLivingExp;
	}


	public void setAddLivingExp(float addLivingExp) {
		this.addLivingExp = addLivingExp;
	}


	public float getMedicalExpenses() {
		return medicalExpenses;
	}


	public void setMedicalExpenses(float medicalExpenses) {
		this.medicalExpenses = medicalExpenses;
	}


	public float getDeductable() {
		return deductable;
	}


	public void setDeductable(float deductable) {
		this.deductable = deductable;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
