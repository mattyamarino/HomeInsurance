package com.perscholas.homeinsurance.model;

public class user1 {
	
	//Attributes
	private int userId;
	private String userName;
	private String userPassword;
	private String adminRole;
	
	//Constructors
	public user1() {
		this.adminRole = "user";
	}
	
	public user1(String userName, String userPassword) {
		this();
		this.userName = userName;
		this.userPassword = userPassword;
		this.adminRole = "user";
	}
	
	
	
	public user1(int userId, String userName, String userPassword) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPassword = userPassword;
		this.adminRole = "user";
	}

	public user1(String userName, String userPassword, String adminRole) {
		super();
		this.userName = userName;
		this.userPassword = userPassword;
		this.adminRole = adminRole;
	}

	public user1(int userId, String userName, String userPassword, String adminRole) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPassword = userPassword;
		this.adminRole = adminRole;
	}
	
	//Getters and Setters

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getAdminRole() {
		return adminRole;
	}

	public void setAdminRole(String adminRole) {
		this.adminRole = adminRole;
	}

}
