package com.perscholas.homeinsurance.model;


import java.time.LocalDate;

public class policy {
	//Attributes
	private int policyId;
	private int quoteId;
	private int userId;
	private LocalDate effectiveDate;
	private LocalDate endDate;
	private int term;
	private String policyStatus;
	
	
	//Constructors
	public policy() {
		super();
	}

	public policy(int quoteId, int userId, LocalDate effectiveDate, LocalDate endDate, int term, String policyStatus) {
		super();
		this.quoteId = quoteId;
		this.userId = userId;
		this.effectiveDate = effectiveDate;
		this.endDate = endDate;
		this.term = term;
		this.policyStatus = policyStatus;
	}

	
	//Getters And Setters
	public int getPolicyId() {
		return policyId;
	}

	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}

	public int getQuoteId() {
		return quoteId;
	}

	public void setQuoteId(int quoteId) {
		this.quoteId = quoteId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public int getTerm() {
		return term;
	}

	public void setTerm(int term) {
		this.term = term;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}
	
	
	
	

}
