package com.perscholas.homeinsurance.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.perscholas.homeinsurance.bo.homeOwnerBo;
import com.perscholas.homeinsurance.bo.locationBo;
import com.perscholas.homeinsurance.bo.propertiesBo;
import com.perscholas.homeinsurance.model.homeOwner;
import com.perscholas.homeinsurance.model.location;
import com.perscholas.homeinsurance.model.properties;
import com.perscholas.homeinsurance.model.user1;


//  TO DO LIST - Verify zip is number, ssn is number, and year built is less than 2020, violating ssn unique constraint
//			 make sure homeowner is of age?


@WebServlet("/quoteProcess")
public class quoteProcess extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String from = request.getParameter("from");
		HttpSession session=request.getSession(false);
		user1 u = (user1) session.getAttribute("user");
		
		if(from.equals("quote")) 
		{
				location loc = new location();
				loc.setUserId(u.getUserId());
				loc.setResidenceType(request.getParameter("restype"));
				loc.setAddressLine1(request.getParameter("add1"));
				loc.setAddressLine2(request.getParameter("add2"));
				loc.setCity(request.getParameter("city"));
				loc.setLocationState(request.getParameter("state"));
					String z = request.getParameter("zip");
					int zip = Integer.parseInt(z);
				loc.setZipCode(zip);
				loc.setResidenceUse(request.getParameter("resuse"));
				
				
				locationBo bo = new locationBo();
				
				try {
					int x = bo.addLocation(loc);
					loc.setLocationId(x);					
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				session.setAttribute("location", loc);
				response.sendRedirect("quoteGet.jsp?page=2");
		}
			
		else if(from.equals("homeowner"))
		{
				homeOwner home = new homeOwner();	
				home.setUserId(u.getUserId());
				home.setFirstName(request.getParameter("fname"));
				home.setLastName(request.getParameter("lname"));
					String d = request.getParameter("dob");
					LocalDate dob = LocalDate.parse(d);
				home.setDateOfBirth(dob);
					if (request.getParameter("retired").equals("Yes")) {home.setRetired(true);}
					else if (request.getParameter("retired").equals("No")) {home.setRetired(false);}
					String s = request.getParameter("ssn");
					int ssn = Integer.parseInt(s);
				home.setSsn(ssn);
				home.setEmail(request.getParameter("email"));
				session.setAttribute("homeowner", home);
				
				homeOwnerBo bo = new homeOwnerBo();
				
				try {
					bo.addHomeOwner(home);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				response.sendRedirect("quoteGet.jsp?page=3");		
		}
		else if(from.equals("prop")) 
		{
				location loc = (location) session.getAttribute("location");
				properties p = new properties();
				
				p.setLocationId(loc.getLocationId());
					String val = request.getParameter("value");
					float mval = Float.parseFloat(val);
				p.setMarketValue(mval);
					String y = request.getParameter("ybuilt");
					int ybuilt = Integer.parseInt(y);
				p.setYearBuilt(ybuilt);
					String sq = request.getParameter("sqft");
					int sqft = Integer.parseInt(sq);
				p.setSquareFootage(sqft);
				p.setDwellingType(request.getParameter("dstyle"));
				p.setRoofMaterial(request.getParameter("rmat"));
				p.setGarageType(request.getParameter("garage"));
					String fb = request.getParameter("fbath");
					int fbath = Integer.parseInt(fb);
				p.setFullBaths(fbath);
					String hb = request.getParameter("hbath");
					int hbath = Integer.parseInt(hb);
				p.setFullBaths(hbath);
					if (request.getParameter("pool").equals("Yes")) {p.setPool(true);}
					else if (request.getParameter("pool").equals("No")) {p.setPool(false);}
				session.setAttribute("property", p);
				
				propertiesBo bo = new propertiesBo();
				
				try {
					bo.addProp(p);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				response.sendRedirect("coverageDetails");
		}
	}

}
