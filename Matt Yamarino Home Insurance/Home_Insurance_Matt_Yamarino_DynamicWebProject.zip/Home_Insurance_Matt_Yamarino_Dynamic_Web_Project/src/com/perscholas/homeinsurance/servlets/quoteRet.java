package com.perscholas.homeinsurance.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.perscholas.homeinsurance.bo.homeOwnerBo;
import com.perscholas.homeinsurance.bo.locationBo;
import com.perscholas.homeinsurance.bo.policyBo;
import com.perscholas.homeinsurance.bo.propertiesBo;
import com.perscholas.homeinsurance.bo.quoteBo;
import com.perscholas.homeinsurance.model.homeOwner;
import com.perscholas.homeinsurance.model.location;
import com.perscholas.homeinsurance.model.policy;
import com.perscholas.homeinsurance.model.properties;
import com.perscholas.homeinsurance.model.quote;
import com.perscholas.homeinsurance.model.user1;


@WebServlet("/quoteRet")
public class quoteRet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession sess=request.getSession(false);
		
			user1 u1 = (user1) sess.getAttribute("user");
			
		sess.invalidate();
		
		HttpSession session=request.getSession(true);
		session.setAttribute("user", u1);
		
			locationBo lb = new locationBo();
			homeOwnerBo hb = new homeOwnerBo();
			propertiesBo pb = new propertiesBo();
			quoteBo qb = new quoteBo();
			location l = new location();
			
			List<location> list;
			list = new ArrayList<location>();
			List<quote> qlist;
			qlist = new ArrayList<quote>();
			boolean boo = false;
			boolean boo2 = false;
			int lid = 0;
			
			try {
				list = lb.fetchAllLocations();		
				for (location v : list)
				{
					if (v.getUserId() == u1.getUserId()) {boo = true; lid = v.getLocationId();}
				}
				
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
	if (boo == true) {
	
				try {
					qlist = qb.fetchAllQuotes();
					for (quote m : qlist)
					{
						if (m.getLocationId() == lid ) {boo2 = true;}
					}
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				if (boo2 == true) {
					
					try {
						l = lb.getLocByUId(u1.getUserId());
						session.setAttribute("location", l);
					} catch (SQLException e3) {
						// TODO Auto-generated catch block
						e3.printStackTrace();
					}
					
					try {
						homeOwner h = hb.getHOByUId(u1.getUserId());
						session.setAttribute("homeowner", h);
					} catch (SQLException e4) {
						// TODO Auto-generated catch block
						e4.printStackTrace();
					}
					
					try {
						properties p = pb.getPropByLId(lid);
						session.setAttribute("property", p);
					} catch (SQLException e5) {
						// TODO Auto-generated catch block
						e5.printStackTrace();
					}
					
					try {
						quote q = qb.getQuoteByUId(lid);
						session.setAttribute("quote", q);
					} catch (SQLException e6) {
						// TODO Auto-generated catch block
						e6.printStackTrace();
					}
					
					//VERIFY IF CUSTOMER ALREADY BOUGHT POLICY
					policyBo pbo = new policyBo();
					
					List<policy> plist;
					plist = new ArrayList<policy>();
					
					try {
						plist = pbo.fetchAllPolicies();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					boolean boo3 = false;
					
					for (policy h : plist) {if (u1.getUserId() == h.getUserId()) {boo3 = true;}}
					
					if (boo3 = true) {response.sendRedirect("quoteSummary.jsp?error=a");}
					else {response.sendRedirect("quoteSummary.jsp");}
			}		
			
			else if (boo2 == false) {response.sendRedirect("quoteFork.jsp?error=a");}
				
				
				
				
					}
	else if (boo == false) {response.sendRedirect("quoteFork.jsp?error=a");}
	
	
	
		
	}

}
