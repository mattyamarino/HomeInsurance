package com.perscholas.homeinsurance.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.perscholas.homeinsurance.bo.policyBo;
import com.perscholas.homeinsurance.model.policy;
import com.perscholas.homeinsurance.model.quote;
import com.perscholas.homeinsurance.model.user1;



@WebServlet("/quoteFinal")
public class quoteFinal extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
		LocalDate sdate = LocalDate.parse(request.getParameter("startdate"));
		
		if (sdate.isAfter(LocalDate.now().plusDays(60))) {response.sendRedirect("quoteBuy.jsp?error=a");}
		else if (sdate.isBefore(LocalDate.now())) {response.sendRedirect("quoteBuy.jsp?error=b");}
		else {
			
			policy pol = new policy();
			user1 u = (user1) session.getAttribute("user");
			quote q = (quote) session.getAttribute("quote");
			policyBo bo = new policyBo();
			
			pol.setUserId(u.getUserId());
			pol.setQuoteId(q.getQuoteId());
			pol.setEffectiveDate(sdate);
			pol.setEndDate(sdate.plusYears(1));
			pol.setTerm(1);
			
			int x = 0;
			
			try {
				x = bo.addPolicy(pol);
				pol.setPolicyId(x);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			try {
				policy pol2 = bo.getPolicyById(pol.getPolicyId());
				pol.setPolicyStatus(pol2.getPolicyStatus());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			session.setAttribute("policy", pol);
			
			response.sendRedirect("policies.jsp");}
		
		
		
		
		
		
		
	}

}
