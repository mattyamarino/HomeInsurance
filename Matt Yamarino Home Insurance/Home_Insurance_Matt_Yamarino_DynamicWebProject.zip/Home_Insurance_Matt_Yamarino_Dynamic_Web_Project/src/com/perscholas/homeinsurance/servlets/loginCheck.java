package com.perscholas.homeinsurance.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.perscholas.homeinsurance.bo.userBo;
import com.perscholas.homeinsurance.model.user1;



@WebServlet("/loginCheck")
public class loginCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname = request.getParameter("username");
		String password = request.getParameter("password");
		
		userBo bo = new userBo();
		user1 u = new user1();
		
		try {
			u = bo.getUserbyUname(uname);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if (u != null) {
		if (u.getUserPassword().equals(password))
			{
			HttpSession session=request.getSession(true);
			session.setAttribute("user",u);  
			response.sendRedirect("quoteFork.jsp");
			}
			
		else {response.sendRedirect("index.jsp?error=a");}
		}
		else {response.sendRedirect("index.jsp?error=a");}
	
	}

}
