package com.perscholas.homeinsurance.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.perscholas.homeinsurance.bo.quoteBo;
import com.perscholas.homeinsurance.model.location;
import com.perscholas.homeinsurance.model.properties;
import com.perscholas.homeinsurance.model.quote;

/**
 * Servlet implementation class coverageDetails
 */
@WebServlet("/coverageDetails")
public class coverageDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		
		location loc = (location) session.getAttribute("location");
		properties prop = (properties) session.getAttribute("property");
		quote quote = new quote();
		quote.setLocationId(loc.getLocationId());
		
//		MONTHLY PREMIUM
	    double eu = prop.getMarketValue() / 1000;
	    float premium = (float) (eu * 5);
	    float premf;
	    
	    if (loc.getResidenceType().equals("Single Family Home")) {premf = (float) (premium * 0.05);}
	    else if (loc.getResidenceType().contentEquals("Townhouse") || loc.getResidenceType().equals("Rowhouse")) {premf = (float) (premium * 0.07);}
	    else {premf = (float) (premium * 1.06);}
	    
	    quote.setMonthlyPremium(premf / 12);
	    
//	    DWELLING COVERAGE
	    float ccost = prop.getSquareFootage() * 120;
	    float value;
	    
	    if (prop.getYearBuilt() >= 2014) {value = (float) (ccost * 0.9);}
	    else if (prop.getYearBuilt() >= 2009) {value = (float) (ccost * 0.8);}
	    else {value = (float) (ccost * 0.5);}
	    
	    float half = prop.getMarketValue() / 2;
	    float fin = half + value;
	    quote.setDwellingCoverage(fin);
	    
//	    THE REST
	    quote.setDetachedStructures((float) (fin * 0.1));
	    quote.setPersonalProperty((float) (fin * 0.6));
	    quote.setAddLivingExp((float) (fin * 0.2));
	    quote.setMedicalExpenses(5000);
	    quote.setDeductable((float) (prop.getMarketValue() * 0.01));
	    
	    quoteBo bo = new quoteBo();
	    int x;
	    
	    try {
			x = bo.addQuote(quote);
			 quote.setQuoteId(x);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    session.setAttribute("quote", quote);
	   
	   response.sendRedirect("coverageDetails.jsp"); 
		
		
	}



}
