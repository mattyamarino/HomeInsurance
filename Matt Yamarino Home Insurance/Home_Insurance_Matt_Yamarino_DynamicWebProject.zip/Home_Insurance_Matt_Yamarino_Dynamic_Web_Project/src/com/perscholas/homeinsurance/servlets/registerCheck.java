package com.perscholas.homeinsurance.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.perscholas.homeinsurance.bo.userBo;
import com.perscholas.homeinsurance.model.user1;


@WebServlet("/registerCheck")
public class registerCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String uname = request.getParameter("username");
		String pass = request.getParameter("password");
		String confirm = request.getParameter("confirm");
		boolean boo = false;
		user1 user = new user1();
		userBo bo = new userBo();
		
		
		try {
			if (bo.getUserbyUname(uname) == null) {boo = true;}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		if (boo == true) {
		
		if (uname.matches("[a-zA-Z0-9]+") && pass.matches("[a-zA-Z0-9]+") && confirm.matches("[a-zA-Z0-9]+")) 
		{
				if (pass.equals(confirm)) 
				{
			
				user.setUserName(uname);
				user.setUserPassword(pass);
				user.setAdminRole("user");
			
				try {
					bo.addUser(user);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				response.sendRedirect("index.jsp?error=b");
				
				}
			else {response.sendRedirect("register.jsp?error=a");}
		
		}
		else {response.sendRedirect("register.jsp?error=b");}
		}
		else {response.sendRedirect("register.jsp?error=c");}
		
	}

}
