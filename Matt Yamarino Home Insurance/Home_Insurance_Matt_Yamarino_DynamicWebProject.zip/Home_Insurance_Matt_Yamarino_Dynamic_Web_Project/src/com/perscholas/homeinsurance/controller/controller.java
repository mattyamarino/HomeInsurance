package com.perscholas.homeinsurance.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.perscholas.homeinsurance.bo.policyBo;
import com.perscholas.homeinsurance.bo.userBo;
import com.perscholas.homeinsurance.model.policy;
import com.perscholas.homeinsurance.model.user1;

@Controller
public class controller {
	
	@RequestMapping(value = "/adminLog")
	public String adminlogin() { return "admin"; }
	
	@RequestMapping(value = "/adminHomePro")
	public String adminreturn(HttpServletRequest request) throws SQLException { 
		HttpSession session = request.getSession(false);
		session.invalidate();
		session = request.getSession(true);
		
		return "adminHome"; }
	
	@RequestMapping(value = "/adminLogProcess", method = RequestMethod.POST)
	public String adminloginprocess(HttpServletRequest request) throws SQLException{
		
		String uname = request.getParameter("username");
		String password = request.getParameter("password");
		
		userBo bo = new userBo();
		user1 u = new user1();
		
		u = bo.getUserbyUname(uname);

		if (u != null) {

			if (u.getUserPassword().equals(password) && u.getAdminRole().trim().equalsIgnoreCase("ADMIN"))
				{
			
				return "adminHome";
				}
				
			else {return "adminRelog";}
			}
			else {return "adminRelog";}
	}
	
	@RequestMapping (value = "/adminRenewConfirm", method = RequestMethod.POST)
	public String renewconfirm(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		int pid = Integer.parseInt(request.getParameter("pid"));
		String s = request.getParameter("renew");
		
		session.setAttribute("pid", pid);
		session.setAttribute("renew", s);
		
		return "adminConfirm";
	}
	
	
	
	@RequestMapping(value = "/adminRenew")
	public String adminRenew(HttpServletRequest request) throws ClassNotFoundException, SQLException, IOException { 
		HttpSession session = request.getSession(false);
		int pid = (int) session.getAttribute("pid");
		String type = (String) session.getAttribute("renew");
		policyBo bo = new policyBo();
		policy p = new policy();
		p.setPolicyId(pid);
				
		if (type.equals("renew")) {
		p.setEndDate(LocalDate.now().plusYears(1));
		p.setPolicyStatus("ACTIVE");	
		}
		else {
		p.setEndDate(LocalDate.now());
		p.setPolicyStatus("CANCELED");	
		}
		
		bo.updatePolicy(p);
		return "adminViewPolicy"; 
		}
	
	@RequestMapping(value = "/searchUser", method = RequestMethod.POST)
	public String searchuser(HttpServletRequest request) {

		int uid = Integer.parseInt(request.getParameter("uid"));
		
		HttpSession session = request.getSession(false);
		if (session == null) {session = request.getSession();}
		session.setAttribute("uid", uid);
		
		return "adminResult";
	}
	
	

}
